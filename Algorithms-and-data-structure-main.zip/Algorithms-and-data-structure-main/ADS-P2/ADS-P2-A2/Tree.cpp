/*************************************************
 * ADS Praktikum 2.2
 * Tree.cpp
 * Erweiterung um Hilfsfunktionen gestattet.
 *************************************************/
#include "Tree.h"
#include "TreeNode.h"
#include <iomanip>
#include <iostream>

using namespace std;

////////////////////////////////////
// Ihr Code hier:
void addNode(string a, int b, double c, int d) {
	int id = b + c + d;
	TreeNode* ptr = Tree::anker;
	


}
//
////////////////////////////////////