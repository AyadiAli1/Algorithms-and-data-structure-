/*************************************************
* ADS Praktikum 2.1
* RingNode.cpp
* Erweiterung um Hilfsfunktionen gestattet.
*************************************************/
#include "RingNode.h"


// Ihr Code hier:


// 
////////////////////////////////////

RingNode::RingNode()
{
	next = 0;
}
